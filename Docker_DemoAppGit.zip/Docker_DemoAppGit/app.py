from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def home():
    return {
        "message": "Welcome to Docker!",
        "status": "Application is running successfully"
    }

@app.get("/health")
def health():
    return {
        "status": "Healthy"
    }

@app.get("/hello/{name}")
def hello(name: str):
    return {
        "message": f"Hello {name}"
    }